# random_numbers

This library contains wrappers for generating floating point values, integers, quaternions using boost libraries.

## Build Status

master branch: [![Build Status](https://travis-ci.org/ros-planning/random_numbers.png?branch=master)](https://travis-ci.org/ros-planning/random_numbers)

## Features

New: you can pass in a custom random number generator seed to allow optional deterministic behavior during debugging, testing, etc. using the secondary constructor.

