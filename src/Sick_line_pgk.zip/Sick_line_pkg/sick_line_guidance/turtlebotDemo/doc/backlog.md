# Backlog

  * Makrolon bekleben nach Vorlage
  * Simulation umsetzen
  * Störungssimulation definieren (Bandbegrenztes normalverteiles Rauschen, systematischer Fehler und Aussetzer (Salt/Pepper))
  * Kidnapping-Problem mit Sick besprechen
  * Beschreibung für Setup der Simulation
  * Beschreibung der Durchführung der Simulation
  
  
Merker: OLS10-Simulation
        Spg.-Versorgung 24V an OLS10 anklemmen und Linux booten (20.06.2019)
        
