var structCO__TPDO__t =
[
    [ "CANdevTx", "structCO__TPDO__t.html#a42d9798fca6a122bd06391b7d23ec254", null ],
    [ "CANdevTxIdx", "structCO__TPDO__t.html#ab401d61f30b73d530df3b8d42015407d", null ],
    [ "CANtxBuff", "structCO__TPDO__t.html#a2a2a10d57e1eeab4e0717caa302a6605", null ],
    [ "dataLength", "structCO__TPDO__t.html#a223e60deb77d4ef8a78da37e4d9cdf85", null ],
    [ "defaultCOB_ID", "structCO__TPDO__t.html#a95e95dc4668b41de0b8eb8504e83c944", null ],
    [ "em", "structCO__TPDO__t.html#ac7ce3386549e212300bb85bfc5e88f2e", null ],
    [ "eventTimer", "structCO__TPDO__t.html#ae71e875f41d8f14f02e757dbc3b2d0c5", null ],
    [ "inhibitTimer", "structCO__TPDO__t.html#a9277687ef658353801435638c8aa2bee", null ],
    [ "mapPointer", "structCO__TPDO__t.html#acb6fa2c4037b1e41afdf6195cd6e93ec", null ],
    [ "nodeId", "structCO__TPDO__t.html#a4ef8ced15f6fffb56a0ec4aeb48d4551", null ],
    [ "operatingState", "structCO__TPDO__t.html#a7ba73f70490869a38ff561aa6c32489f", null ],
    [ "restrictionFlags", "structCO__TPDO__t.html#aa0d1d4b71933c7bac438d97ca280fe56", null ],
    [ "SDO", "structCO__TPDO__t.html#a52c1e56f282549b0949721049bcc7e73", null ],
    [ "sendIfCOSFlags", "structCO__TPDO__t.html#a0f5dbb51df08261c466b079c08119a04", null ],
    [ "sendRequest", "structCO__TPDO__t.html#afc375e06e5931cb8bae7886f2f5f0f7a", null ],
    [ "SYNC", "structCO__TPDO__t.html#ae6c014bdb855d57d4c53bc702734b51f", null ],
    [ "syncCounter", "structCO__TPDO__t.html#a5bf0fa473c5eb92e3b56fc1f17222976", null ],
    [ "TPDOCommPar", "structCO__TPDO__t.html#ab9bd2bf1a76f1f0e253dd4c4a941ba67", null ],
    [ "TPDOMapPar", "structCO__TPDO__t.html#a6f6202c2b866f552c512a3513c27be8b", null ],
    [ "valid", "structCO__TPDO__t.html#a201c8a0726347a747f6b315915c797fb", null ]
];