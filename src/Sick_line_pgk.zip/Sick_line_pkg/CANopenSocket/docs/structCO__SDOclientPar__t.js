var structCO__SDOclientPar__t =
[
    [ "COB_IDClientToServer", "structCO__SDOclientPar__t.html#a97156e903912e377a0da080cac37f18c", null ],
    [ "COB_IDServerToClient", "structCO__SDOclientPar__t.html#a220dbc2cb1bccb5c5fb8f946432b4690", null ],
    [ "maxSubIndex", "structCO__SDOclientPar__t.html#a5ef89763f1af3c4a5aa3b6cf825d5e83", null ],
    [ "nodeIDOfTheSDOServer", "structCO__SDOclientPar__t.html#ae6ac6800e3544fe66fe4fada680606b4", null ]
];