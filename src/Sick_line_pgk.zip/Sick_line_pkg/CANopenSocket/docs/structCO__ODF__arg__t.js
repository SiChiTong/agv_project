var structCO__ODF__arg__t =
[
    [ "attribute", "structCO__ODF__arg__t.html#a8c3e7dfff541e9a88bb9260c5c54b3bf", null ],
    [ "data", "structCO__ODF__arg__t.html#aed52db21f874291edecd6b4d77a69d13", null ],
    [ "dataLength", "structCO__ODF__arg__t.html#aea5dc99358f880040711eb6046a9c286", null ],
    [ "dataLengthTotal", "structCO__ODF__arg__t.html#a84d9ba93381c52777af37f7786d50471", null ],
    [ "firstSegment", "structCO__ODF__arg__t.html#a10fad89f44321d6167d8d17c6f4c37c2", null ],
    [ "index", "structCO__ODF__arg__t.html#a3498f7e295008fc6196586c4049e0159", null ],
    [ "lastSegment", "structCO__ODF__arg__t.html#ac1cb1d8b5a484fad297863101213624e", null ],
    [ "object", "structCO__ODF__arg__t.html#a1df0ce97fc7f6666817efa74c5c061a9", null ],
    [ "ODdataStorage", "structCO__ODF__arg__t.html#aea12297d0fdd0ea0b1c69d203c90eb74", null ],
    [ "offset", "structCO__ODF__arg__t.html#a42223bb6a7b6912aaf98c82bcecb1362", null ],
    [ "pFlags", "structCO__ODF__arg__t.html#a7624a1fa20feaffe1e363e874e88165f", null ],
    [ "reading", "structCO__ODF__arg__t.html#a641827d4f18322071a98141c3e6e7d42", null ],
    [ "subIndex", "structCO__ODF__arg__t.html#a6f3fce74bd9ced3072884c730c875ebb", null ]
];