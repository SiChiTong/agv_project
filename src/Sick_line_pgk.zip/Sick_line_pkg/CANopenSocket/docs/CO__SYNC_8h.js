var CO__SYNC_8h =
[
    [ "CO_SYNC_status_t", "group__CO__SYNC.html#ga121ede6e0c90c66076a7ed950db38517", [
      [ "CO_SYNC_NONE", "group__CO__SYNC.html#gga121ede6e0c90c66076a7ed950db38517aeff7846423b9eb92cd2c69df745ea429", null ],
      [ "CO_SYNC_RECEIVED", "group__CO__SYNC.html#gga121ede6e0c90c66076a7ed950db38517aa03c21a78b503a4adebb2d9d7aa655bf", null ],
      [ "CO_SYNC_OUTSIDE_WINDOW", "group__CO__SYNC.html#gga121ede6e0c90c66076a7ed950db38517a5b112bec6cb10119879703a6313de41e", null ]
    ] ],
    [ "CO_SYNC_init", "group__CO__SYNC.html#ga3047b679d5e3261eedf1980ea87b5135", null ],
    [ "CO_SYNC_initCallbackPre", "group__CO__SYNC.html#gaf1005766c7f1588262b018fe04960777", null ],
    [ "CO_SYNC_process", "group__CO__SYNC.html#ga66b8f42fd430daa2a57ff15aa49c814c", null ]
];