var globals_dup =
[
    [ "b", "globals.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "f", "globals_f.html", null ],
    [ "i", "globals_i.html", null ],
    [ "l", "globals_l.html", null ],
    [ "n", "globals_n.html", null ],
    [ "o", "globals_o.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ]
];