var structCO__CANinterfaceErrorhandler__t =
[
    [ "fd", "structCO__CANinterfaceErrorhandler__t.html#a06e667f1f90ad62495aa2172d97305b8", null ],
    [ "ifName", "structCO__CANinterfaceErrorhandler__t.html#a58a5219f8dad7dc1c98db2b463e6e005", null ],
    [ "listenOnly", "structCO__CANinterfaceErrorhandler__t.html#a96ddaefd75e680898f93d4891f5fc195", null ],
    [ "noackCounter", "structCO__CANinterfaceErrorhandler__t.html#a6d17a248ec3ce1f6c53f4315c0cb9282", null ],
    [ "timestamp", "structCO__CANinterfaceErrorhandler__t.html#a615dfcafdb866ae951296333df35d1c7", null ]
];