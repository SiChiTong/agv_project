var structCO__HBconsumer__t =
[
    [ "allMonitoredActive", "structCO__HBconsumer__t.html#aaff60bb59e36a3b0ddd11b45268eaf33", null ],
    [ "allMonitoredOperational", "structCO__HBconsumer__t.html#a9407103796db857229ec5b266c580b37", null ],
    [ "CANdevRx", "structCO__HBconsumer__t.html#af5d8828478e2b51fe47a63f24dd896b1", null ],
    [ "CANdevRxIdxStart", "structCO__HBconsumer__t.html#a00d176c84d169115399c276031b71722", null ],
    [ "em", "structCO__HBconsumer__t.html#aae5e363ccc6a6fd3b17a35e0430add2a", null ],
    [ "HBconsTime", "structCO__HBconsumer__t.html#a1cd314f387357f2ce13d4093f477fff5", null ],
    [ "monitoredNodes", "structCO__HBconsumer__t.html#a737b37c544a28eff8de0b03b51cbeec8", null ],
    [ "NMTisPreOrOperationalPrev", "structCO__HBconsumer__t.html#a2fe3d81e2124918d0d5947e6891a060e", null ],
    [ "numberOfMonitoredNodes", "structCO__HBconsumer__t.html#a5b944043074d42017be3b76320030542", null ],
    [ "pFunctSignalNmtChanged", "structCO__HBconsumer__t.html#a387497807b3fdc2d61ad0fa492502e8b", null ],
    [ "pFunctSignalObjectNmtChanged", "structCO__HBconsumer__t.html#ad583c93f4e59f98669cd18f263aee45a", null ]
];