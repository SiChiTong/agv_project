var structCO__OD__entry__t =
[
    [ "attribute", "structCO__OD__entry__t.html#ac5260ae7daf526bb42a2df6708656dd3", null ],
    [ "index", "structCO__OD__entry__t.html#a4cc69841652c66e0d9a5f5b6e0d0f49a", null ],
    [ "length", "structCO__OD__entry__t.html#a297404810118fd3c36e10c70c39e4ed3", null ],
    [ "maxSubIndex", "structCO__OD__entry__t.html#a6c7cf30d5ff476792a81ddb2fe29be2c", null ],
    [ "pData", "structCO__OD__entry__t.html#ad0eb66c2703cb380d4e0da0411a13aab", null ]
];