var structCO__LEDs__t =
[
    [ "LEDgreen", "structCO__LEDs__t.html#ac2b4eb053725681f1935c8a6e4184f85", null ],
    [ "LEDred", "structCO__LEDs__t.html#ad8624f0baa6186e523e072e6101c7a84", null ],
    [ "LEDtmr200ms", "structCO__LEDs__t.html#a2690fe669ce01322e14de1b9f559a147", null ],
    [ "LEDtmr50ms", "structCO__LEDs__t.html#ae27f4bbc313e08e25b9b1e1d515ea9e4", null ],
    [ "LEDtmrflash_1", "structCO__LEDs__t.html#a2431d9736416e1b5b6c57f61f029dc04", null ],
    [ "LEDtmrflash_2", "structCO__LEDs__t.html#ae6aa2a97a9496abc67774d94caa0ea1a", null ],
    [ "LEDtmrflash_3", "structCO__LEDs__t.html#ad3af9ed6c2c43330cc3eadb3b76de2c4", null ],
    [ "LEDtmrflash_4", "structCO__LEDs__t.html#ae33491a6eed2761893fea47dd65c5a78", null ]
];