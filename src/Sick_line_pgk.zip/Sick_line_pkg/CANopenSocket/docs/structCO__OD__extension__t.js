var structCO__OD__extension__t =
[
    [ "flags", "structCO__OD__extension__t.html#aacca0a05e91693608627d44bbbb5b962", null ],
    [ "object", "structCO__OD__extension__t.html#a7ac58b6315bf1ba7c9a28a0d71b7a260", null ],
    [ "pODFunc", "structCO__OD__extension__t.html#a7fefe8873bf7ffdcc32efd59c3d30eda", null ]
];