var structCO__CANmodule__t =
[
    [ "bufferInhibitFlag", "structCO__CANmodule__t.html#ad7af19de0bf39c8927c926b095cb5292", null ],
    [ "CANnormal", "structCO__CANmodule__t.html#a5555f7d10e09da5815526d7c8b10901d", null ],
    [ "CANptr", "structCO__CANmodule__t.html#aad1c18f6d47621e5a611333dc57cb349", null ],
    [ "CANtxCount", "structCO__CANmodule__t.html#a269294aa6a15ba56f92a460fae0536ac", null ],
    [ "em", "structCO__CANmodule__t.html#a4b09fd4331f837d94c30ba102532764a", null ],
    [ "errOld", "structCO__CANmodule__t.html#aa0627988ddedc3a4ec3bbfcf3b818d06", null ],
    [ "firstCANtxMessage", "structCO__CANmodule__t.html#ac12bd37971b89b5796fec0de71be0f07", null ],
    [ "rxArray", "structCO__CANmodule__t.html#a747e694e15cca5a5579c2c4397a6da39", null ],
    [ "rxSize", "structCO__CANmodule__t.html#a88edfd32c2bff5b9f29a2bccd1ac96f3", null ],
    [ "txArray", "structCO__CANmodule__t.html#af623f2a045716af77e906b28deee3d3c", null ],
    [ "txSize", "structCO__CANmodule__t.html#a6a53d3d12efbe30d1ee08e821d1b4139", null ],
    [ "useCANrxFilters", "structCO__CANmodule__t.html#a9b28f7a6f02d398b3a0ea6cf70fa64f0", null ]
];