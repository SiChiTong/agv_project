var CO__LSSslave_8h =
[
    [ "CO_LSSslave_init", "group__CO__LSSslave.html#gac445bdc7af5920e798196b1c3a48cbe0", null ],
    [ "CO_LSSslave_initActivateBitRateCallback", "group__CO__LSSslave.html#ga0253fffcb36ab6b850563328784a8a5a", null ],
    [ "CO_LSSslave_initCallbackPre", "group__CO__LSSslave.html#ga64c23178117a707046eb15ebc6506429", null ],
    [ "CO_LSSslave_initCfgStoreCallback", "group__CO__LSSslave.html#gadc6187357904293da0a35317f15d0666", null ],
    [ "CO_LSSslave_initCheckBitRateCallback", "group__CO__LSSslave.html#ga665f147d6fae6db71173c4a8d602495c", null ],
    [ "CO_LSSslave_process", "group__CO__LSSslave.html#gae19d7ad84333f1a3f40ecbdbf639e017", null ]
];