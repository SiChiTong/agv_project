var group__CO__CANopen__303 =
[
    [ "LED indicator specification", "group__CO__LEDs.html", "group__CO__LEDs" ]
];