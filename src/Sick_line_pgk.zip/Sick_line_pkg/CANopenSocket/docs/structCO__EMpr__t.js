var structCO__EMpr__t =
[
    [ "CANdev", "structCO__EMpr__t.html#a8f93114514c22ccf03ffd772b764bf57", null ],
    [ "CANtxBuff", "structCO__EMpr__t.html#acc7eec8e561fb05f72ec2ce17cd32450", null ],
    [ "em", "structCO__EMpr__t.html#ab17b2c9233f68fd262708369c03a7b08", null ],
    [ "errorRegister", "structCO__EMpr__t.html#a8045c7d98f0267e39b6510fca70e397c", null ],
    [ "inhibitEmTimer", "structCO__EMpr__t.html#a9bf3d06240a78e88c3a1f86df98417e5", null ],
    [ "preDefErr", "structCO__EMpr__t.html#abd11948323b7344744fe3ed90651dea6", null ],
    [ "preDefErrNoOfErrors", "structCO__EMpr__t.html#a9218315c2a16d6340a8a92d4c871e40e", null ],
    [ "preDefErrSize", "structCO__EMpr__t.html#a7e448ed2180077cd49979c217efdbf08", null ]
];