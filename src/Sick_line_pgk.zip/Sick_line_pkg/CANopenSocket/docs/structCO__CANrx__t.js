var structCO__CANrx__t =
[
    [ "ident", "structCO__CANrx__t.html#a8595c238cf0364bde995dee97d321909", null ],
    [ "mask", "structCO__CANrx__t.html#af7a48dd4ac895a19c4031038e2c1222d", null ],
    [ "object", "structCO__CANrx__t.html#a957a1ce67cd1d9010889d557bf0c5770", null ],
    [ "pCANrx_callback", "structCO__CANrx__t.html#a8e4668eec8326bb9ac08d67afc3060c7", null ]
];