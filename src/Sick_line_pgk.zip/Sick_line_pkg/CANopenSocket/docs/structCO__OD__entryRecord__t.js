var structCO__OD__entryRecord__t =
[
    [ "attribute", "structCO__OD__entryRecord__t.html#a7dc5c3a3a22129f9d0bb774fe0d04585", null ],
    [ "length", "structCO__OD__entryRecord__t.html#ab46370f27edc63a999af7ab8a3a2a98f", null ],
    [ "pData", "structCO__OD__entryRecord__t.html#aeece4ce85ff69f0bd4f29672db745473", null ]
];