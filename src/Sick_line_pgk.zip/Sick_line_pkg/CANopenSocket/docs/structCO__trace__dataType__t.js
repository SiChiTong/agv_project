var structCO__trace__dataType__t =
[
    [ "pGetValue", "structCO__trace__dataType__t.html#a8ac5cd02c39b591354149f8c5d6357f7", null ],
    [ "printPoint", "structCO__trace__dataType__t.html#aef2341fd443f3aa33a11db1b429b7dc1", null ],
    [ "printPointEnd", "structCO__trace__dataType__t.html#a48ec81e33885a9114f2ea0be237a0059", null ],
    [ "printPointStart", "structCO__trace__dataType__t.html#a751d9b94aba8f663de5b5f7c7f074893", null ]
];