var CO__SDOclient_8h =
[
    [ "CO_SDOclient_return_t", "group__CO__SDOclient.html#gaa38d674b172da3c57fddace8fa0b868a", [
      [ "CO_SDOcli_uploadDataBufferFull", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aad67556adcdadd513cc00d3464610a888", null ],
      [ "CO_SDOcli_transmittBufferFull", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aa157507e44bca426b45f2e4c13686c0d3", null ],
      [ "CO_SDOcli_blockDownldInProgress", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aa4123d07a663696fa4cd515f8c5b36397", null ],
      [ "CO_SDOcli_blockUploadInProgress", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aa168222ee38f4c7d9744fc67a467a839d", null ],
      [ "CO_SDOcli_waitingServerResponse", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aa266a7c597a30e81cb5dc18284bb8d900", null ],
      [ "CO_SDOcli_ok_communicationEnd", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aa9faf7563ad5be1d9b4c5a11a2e537384", null ],
      [ "CO_SDOcli_wrongArguments", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aabac6580473faee60bd0c60a8db437f59", null ],
      [ "CO_SDOcli_endedWithClientAbort", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aaf4a482ebc8986ff3c61ab035a7a81ba1", null ],
      [ "CO_SDOcli_endedWithServerAbort", "group__CO__SDOclient.html#ggaa38d674b172da3c57fddace8fa0b868aabdf47f3f44f5afee32dd4cbf010f7018", null ]
    ] ],
    [ "CO_SDOclient_init", "group__CO__SDOclient.html#ga1e0a82ce753211c6eb9721d47e8be05a", null ],
    [ "CO_SDOclient_initCallbackPre", "group__CO__SDOclient.html#ga4377eaecc3bd0a8320a2bbe1ef0ef776", null ],
    [ "CO_SDOclient_setup", "group__CO__SDOclient.html#gaba54e09c9987d34cbef7d982d3b1c6c3", null ],
    [ "CO_SDOclientClose", "group__CO__SDOclient.html#ga9b98ea2c36f864f1a589c842528b12ab", null ],
    [ "CO_SDOclientDownload", "group__CO__SDOclient.html#ga97e554a6a01f32eea178ff9541cfce02", null ],
    [ "CO_SDOclientDownloadBufWrite", "group__CO__SDOclient.html#ga958d0568bd47d9a3152f9ea8d104b5f5", null ],
    [ "CO_SDOclientDownloadInitiate", "group__CO__SDOclient.html#ga6599e156e045d145783372387387ac5a", null ],
    [ "CO_SDOclientDownloadInitiateSize", "group__CO__SDOclient.html#gaf58b7731b4285538c26a0c7c49ab24b6", null ],
    [ "CO_SDOclientUpload", "group__CO__SDOclient.html#ga71f1bdb1222adda40c9ce612414bd88d", null ],
    [ "CO_SDOclientUploadBufRead", "group__CO__SDOclient.html#gaf5cd4e009476b15a2cd995a9841fb175", null ],
    [ "CO_SDOclientUploadInitiate", "group__CO__SDOclient.html#ga38f19daa81decfbd510425e95ed7e0d3", null ]
];