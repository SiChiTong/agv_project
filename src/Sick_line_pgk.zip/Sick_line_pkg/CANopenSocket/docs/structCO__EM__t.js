var structCO__EM__t =
[
    [ "buf", "structCO__EM__t.html#ac4a07abc9fbd4629ef210a1368177bb4", null ],
    [ "bufEnd", "structCO__EM__t.html#a7675a1b368fcc3c57603ac28d2f3443d", null ],
    [ "bufFull", "structCO__EM__t.html#a8937aa9e6adaaeed1620c2e2b4216d61", null ],
    [ "bufReadPtr", "structCO__EM__t.html#a511dbc5dfc408ad9f186194eb2ec1fbe", null ],
    [ "bufWritePtr", "structCO__EM__t.html#aca4f4d30dea241e224c0616312644144", null ],
    [ "errorStatusBits", "structCO__EM__t.html#adc244a1ebf8e32784cc07cef8a6e2118", null ],
    [ "errorStatusBitsSize", "structCO__EM__t.html#ac13b854f36eda78ec92db778ab7f8e43", null ],
    [ "functSignalObjectPre", "structCO__EM__t.html#ac1dec593fd20fbf7ccc5e8287e27b2d8", null ],
    [ "pFunctSignalPre", "structCO__EM__t.html#a124a5d8fb51bb600618a9427b14663c4", null ],
    [ "pFunctSignalRx", "structCO__EM__t.html#a71ba138e5c1814446c210ac7d7f2aa02", null ],
    [ "wrongErrorReport", "structCO__EM__t.html#a1c0c2d7befb1baefcd9545776b2eed93", null ]
];