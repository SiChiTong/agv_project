var structCO__OD__storage__t =
[
    [ "filename", "structCO__OD__storage__t.html#afb3dd08b01bf20f251754c32b116d8fe", null ],
    [ "fp", "structCO__OD__storage__t.html#a8976cb73fd4a2baadc4689fdb8b876a1", null ],
    [ "lastSavedUs", "structCO__OD__storage__t.html#a94d80f0c140485ab426891839b356347", null ],
    [ "odAddress", "structCO__OD__storage__t.html#ac434d6480330c026761fe8a82e32839b", null ],
    [ "odSize", "structCO__OD__storage__t.html#aefd1cb33fa031c1592b20643bb38bfbb", null ]
];