var structCO__LSSmaster__fastscan__t =
[
    [ "found", "structCO__LSSmaster__fastscan__t.html#a9c34a389339a46da81f2234443f20fb9", null ],
    [ "match", "structCO__LSSmaster__fastscan__t.html#a69540f77885162e936803a9526d3c342", null ],
    [ "scan", "structCO__LSSmaster__fastscan__t.html#a42853c0091c96d7fc7e763c2be3b6e8a", null ]
];