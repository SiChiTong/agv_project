var structCO__TPDOCommPar__t =
[
    [ "COB_IDUsedByTPDO", "structCO__TPDOCommPar__t.html#a65ee2e80b1078e84479ab749012f94cc", null ],
    [ "compatibilityEntry", "structCO__TPDOCommPar__t.html#acba30527976f508b43b3348846f2e657", null ],
    [ "eventTimer", "structCO__TPDOCommPar__t.html#ab01f44570dca08c910c17b14fc664414", null ],
    [ "inhibitTime", "structCO__TPDOCommPar__t.html#ad53403c65582d166898546e329ea9587", null ],
    [ "maxSubIndex", "structCO__TPDOCommPar__t.html#a74a8681177fabbb55ebf5be843f12fc5", null ],
    [ "SYNCStartValue", "structCO__TPDOCommPar__t.html#a597bd93f097550c3d869307e733cd198", null ],
    [ "transmissionType", "structCO__TPDOCommPar__t.html#a328398227ff1f167649d54453e44df97", null ]
];